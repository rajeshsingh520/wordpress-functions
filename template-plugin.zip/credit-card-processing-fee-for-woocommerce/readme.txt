=== Credit Card Processing Fee for WooCommerce ===
Contributors: jyotsnasingh520
Tags: credit card, processing fee, WooCommerce
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Credit Card Processing Fee for WooCommerce is a powerful plugin designed to help you manage and apply credit card processing fees to your WooCommerce store.

== Description ==

Credit Card Processing Fee for WooCommerce is a powerful plugin designed to help you manage and apply credit card processing fees to your WooCommerce store.