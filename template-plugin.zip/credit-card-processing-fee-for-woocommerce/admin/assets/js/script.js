/**
 * JavaScript for initializing the color picker in order tag edit screen
 */
(function($) {
    'use strict';
    
    
    jQuery(function($) {
      
    });
    
})(jQuery);