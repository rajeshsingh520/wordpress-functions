<?php
namespace PISOL\CCPFW\ADMIN;

class Basic_Option extends Option {

    static $instance = null;

    static function get_instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        parent::__construct();
    }

    public function get_tab_name() {
        return __('Processing fee', 'credit-card-processing-fee-for-woocommerce');
    }

    public function get_tab() {
        return 'default';
    }

    public function get_setting_key() {
        return 'processing_fee';
    }

    public function get_icon() {
        return plugin_dir_url( __FILE__ ) . 'img/review-icon.svg';
    }

    public function init_settings() {
        $this->settings = array(
            array('field'=>'title', 'class'=> 'bg-primary text-light', 'class_title'=>'text-light font-weight-light h4', 'label'=> __("When to trigger the notification of Processing fee",'credit-card-processing-fee-for-woocommerce'), 'type'=>"setting_category"),

            
        );
    }

   
}

