<?php 

if ( ! defined( 'ABSPATH' ) ) exit;

use PISOL\CCPFW\ADMIN\Admin_Bootstrap;
use PISOL\CCPFW\FRONT\Front_Bootstrap;

class PISOL_CCPFW_Main{
    static $instance = null;

    public static function get_instance(){
        if(is_null(self::$instance)){
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct(){
        Admin_Bootstrap::get_instance();
        Front_Bootstrap::get_instance();
    }

}