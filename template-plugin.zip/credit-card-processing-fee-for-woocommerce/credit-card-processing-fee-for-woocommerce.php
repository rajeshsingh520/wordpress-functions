<?php
/*
 * Plugin Name:       Credit Card Processing Fee for WooCommerce
 * Plugin URI:        https://www.piwebsolution.com/
 * Description:       This plugin allows you to add a credit card processing fee to your WooCommerce store, helping you cover the costs associated with credit card transactions.
 * Version:           1.0.0
 * Author URI:        https://www.piwebsolution.com/shop
 * Author:            PI Websolution
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       credit-card-processing-fee-for-woocommerce
 * Requires Plugins: woocommerce
*/

if ( ! defined( 'WPINC' ) ) {
    die;
}

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

if(!is_plugin_active( 'woocommerce/woocommerce.php')){
    add_action( 'admin_notices', function () {
        ?>
        <div class="error notice">
            <p><?php esc_html_e( '⚠️ Please Install and Activate WooCommerce plugin, without that this plugin cant work', 'credit-card-processing-fee-for-woocommerce' ); ?></p>
        </div>
        <?php
    } );
    return;
}

if(!function_exists('pisol_ccpfw_error_log')){
    function pisol_ccpfw_error_log($message, $context = 'custom') {
        if (class_exists('WC_Logger')) {
            $logger = wc_get_logger();
            $logger->error(is_string($message) ? $message : wp_json_encode($message), array('source' => 'CCPFW', 'context' => $context));
        }
    }
}

add_action( 'plugin_action_links_' . plugin_basename( __FILE__ ),  function ( $links ) {
    $links = array_merge( array(
        '<a href="' . esc_url( admin_url( '/admin.php?page=credit-card-processing-fee-for-woocommerce' ) ) . '">' . esc_html__( 'Settings', 'credit-card-processing-fee-for-woocommerce' ) . '</a>',
        '<a style="color:#0a9a3e; font-weight:bold;" target="_blank" href="'.esc_url(admin_url('/edit.php?post_type=pisol_ccpfw_notice')).'">' . esc_html__( 'Notification','credit-card-processing-fee-for-woocommerce' ) . '</a>'
    ), $links );
    return $links;
} );



/**
 * Declare compatible with HPOS new order table 
 */
add_action( 'before_woocommerce_init', function() {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

define( 'PISOL_CCPFW_VERSION', '1.0.1' );
define( 'PISOL_CCPFW_FOLDER_URL', plugin_dir_url( __FILE__ ));
define( 'PISOL_CCPFW_FOLDER_PATH', plugin_dir_path( __FILE__ ));
define( 'PISOL_CCPFW_FOLDER_NAME',  dirname( plugin_basename( __FILE__ ) ));
define( 'PISOL_CCPFW_PLUGIN_NAME',  'credit-card-processing-fee-for-woocommerce');

define( 'PISOL_CCPFW_WOOCOMMERCE_PLUGIN_FOLDER', plugin_basename( __DIR__ ) );
define( 'PISOL_CCPFW_WOOCOMMERCE_PLUGIN_PATH', plugin_basename( __FILE__ ) );
define( 'PISOL_CCPFW_WOOCOMMERCE_PLUGIN_FILE',  __FILE__  );

require plugin_dir_path( __FILE__ ) . 'autoloader.php';
require plugin_dir_path( __FILE__ ) . 'class-main.php';

PISOL_CCPFW_Main::get_instance();







